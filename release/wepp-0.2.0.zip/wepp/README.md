# wepp · a node based LESS/CSS and JavaScript Preprocessor

* Website with download, docs and demo: <http://larsjung.de/wepp>
* Sources: <http://github.com/lrsjng/wepp>

wepp is provided under the terms of the [MIT License](http://github.com/lrsjng/wepp/blob/master/LICENSE.txt).  
It comes with a node moduled version of YUI CSS compressor which is licensed under the terms
of the [BSD License](http://github.com/lrsjng/wepp/blob/master/src/wepp/lib/cssmin.js).


## Changelog

### v0.2.0 · *2011-09-??*

* updated `package.json`
* added comments to `wepp.ant.xml`
* updated `cssmin.js` to version from 2011-09-02


### v0.1.0 · *2011-08-30*

